import  ProductStore  from "./ProductStore.js"

export const store = {
    productStore: new ProductStore()
}